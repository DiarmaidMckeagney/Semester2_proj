<template>
  <div id="app">
    <!-- Header component included at the top, so it appears on all pages -->
    <AppHeader />

    <main>
      <router-view></router-view>
    </main>
    <!-- Footer component included at the bottom, so it appears on all pages -->
    <TheFooter />
  </div>
</template>

<script>
import AppHeader from './components/AppHeader.vue'; // Import the Header component
import TheFooter from './components/TheFooter.vue'; // Import the Footer component

export default {
  components: {
    AppHeader,// Register the Header component
    TheFooter
  }
};
</script>

<style>
/* Your global CSS styles can go here */
</style>
