<template>
  <div id="friends-message-page">
    <!-- Header Section -->
    <div class="header" style="text-align: center; background-color: #333; padding: 20px;">
      <h1 style="color: white;">Friends Page</h1>
    </div>

    <!-- Main Content Section -->
    <main style="display: flex; padding: 20px;">
      <!-- Friends List Section -->
      <aside style="width: 20%; background-color: #ddd; padding: 20px;">
        <h2>Friends</h2>
        <div style="margin-bottom: 10px;">Search Placeholder</div>
        <div>Users List Placeholder</div>
      </aside>

      <!-- Placeholder for the Chat Box -->
      <section style="flex-grow: 1; background-color: #f0f0f0; padding: 20px;">
        <div style="background-color: white; padding: 20px; margin-bottom: 10px;">Profile Pic Placeholder</div>
        <div style="background-color: white; padding: 20px; margin-bottom: 10px;">Name / Bio Placeholder</div>
        <!-- Placeholder for messages -->
        <div style="background-color: white; padding: 20px; margin-bottom: 10px;">Message Box Placeholder</div>
        <!-- Text Entry Box Placeholder -->
        <div style="background-color: white; padding: 20px; margin-top: auto;">Text Entry Box Placeholder</div>
      </section>
    </main>

  </div>
</template>

<style scoped>
/* Add your CSS here, and replace inline styles when you're ready */
</style>
