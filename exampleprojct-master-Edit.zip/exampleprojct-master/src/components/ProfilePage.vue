<template>
  <div id="profile-page">
    <!-- Profile Header -->
    <div class="profile-header" style="display: flex; justify-content: space-between; padding: 20px; background-color: #333;">
      <div style="background-color: #555; width: 50px; height: 50px; border-radius: 50%;"></div>
      <h1 style="color: white;">Profile page</h1>
      <div style="background-color: #555; width: 50px; height: 50px;"></div>
    </div>

    <!-- Main Content Section -->
    <main style="display: flex; padding: 20px;">
      <!-- Bio Section -->
      <section style="width: 70%; background-color: #f0f0f0; padding: 20px; margin-right: 20px;">
        <h2>Name and bio/details underneath</h2>
        <div>Recent posts and in what community</div>
      </section>

      <!-- Communities and Friends Tabs -->
      <aside style="width: 30%; background-color: #ddd; padding: 20px;">
        <div style="margin-bottom: 20px;">communities</div>
        <div style="margin-bottom: 20px;">friends</div>
        <div>Community list and Friend list in different tabs of this are</div>
      </aside>
    </main>

  </div>
</template>

<style scoped>
/* Add your CSS here, and replace inline styles when you're ready */
</style>
