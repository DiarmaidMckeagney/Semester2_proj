<template>
  <footer class="footer" style="background-color: #333; color: white; text-align: center; padding: 20px;">
    <router-link to="/support">Support</router-link> |
    <router-link to="/about">About Us</router-link> |
    <router-link to="/privacy-policy">Privacy Policy</router-link> |
    <router-link to="/cookie-policy">Cookie Policy</router-link>
  </footer>
</template>

<script>
export default {
  name: 'TheFooter'
};
</script>

<style scoped>
/* Style for footer links */
.footer a {
  color: white;
  margin: 0 10px;
  text-decoration: none;
}

.footer a:hover {
  text-decoration: underline;
}
</style>
