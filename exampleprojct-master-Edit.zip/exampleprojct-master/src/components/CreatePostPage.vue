<template>
  <div>
    <h2>Create a Post</h2>
    <!-- Form for creating a post -->
    <router-link to="/create-post">Go to Create Post</router-link>
    <!-- You can add the post creation form here -->
  </div>
</template>

<script>
export default {
  // Logic for creating a post
};
</script>

<style scoped>
/* CSS for Create Post Page */
</style>
