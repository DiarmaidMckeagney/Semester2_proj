<template>
  <div id="about-page">
    <!-- Header Section -->
    <div class="about-header" style="background-color: #333; color: white; padding: 20px; text-align: center;">
      <h1>About Us</h1>
    </div>

    <!-- Main Content Section -->
    <main style="display: flex; justify-content: space-between; padding: 20px;">
      <!-- About Content Section -->
      <section style="width: 70%;">
        <h2>About Us</h2>
        <p>Who are we  ?</p>
        <p>Need to think of something nice to write here </p>
      </section>

      <!-- Contact Section -->
      <aside style="width: 28%; background-color: #ddd; padding: 10px;">
        <h2>Contact Us</h2>
        <p>Email: example@example.com</p>
        <p>Phone: 123 456 789</p>
        <p>Address: Looney Tunes Corporation </p>
      </aside>
    </main>

  </div>
</template>

<style scoped>
/* Add your CSS here */
</style>
