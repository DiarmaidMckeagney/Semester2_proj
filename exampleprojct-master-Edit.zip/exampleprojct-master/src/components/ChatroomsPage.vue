<template>
  <div id="chatrooms-page">
    <!-- Header Section -->
    <div class="chatrooms-header" style="text-align: center; background-color: #333; color: white; padding: 20px;">
      <h1>Chatrooms</h1>
    </div>

    <!-- Main Content Section -->
    <main style="display: flex; flex-direction: row; padding: 20px;">
      <!-- Chatroom List Section -->
      <section style="width: 66%; margin-right: 4%;">
        <h2>What's New in Chatrooms</h2>
        <ul>
          <!-- List of Chatrooms -->
          <li style="border: 1px solid #ccc; margin-bottom: 10px; padding: 10px; background-color: #f0f0f0;">
            <span>Chatroom 1</span>
            <button class="join-button" style="background-color: #333; color: white;">Join</button>
          </li>
          <li style="border: 1px solid #ccc; margin-bottom: 10px; padding: 10px; background-color: #f0f0f0;">
            <span>Chatroom 2</span>
            <button class="join-button" style="background-color: #333; color: white;">Join</button>
          </li>
          <li style="border: 1px solid #ccc; margin-bottom: 10px; padding: 10px; background-color: #f0f0f0;">
            <span>Chatroom 3</span>
            <button class="join-button" style="background-color: #333; color: white;">Join</button>
          </li>
          <!-- Create New Chatroom -->
          <li style="border: 1px solid #ccc; margin-bottom: 10px; padding: 10px; background-color: #f0f0f0;">
            <span>Create New Chat</span>
            <button class="join-button" style="background-color: #333; color: white;">Create</button>
          </li>
        </ul>
      </section>

      <!-- Box on the Right -->
      <section style="width: 30%; background-color: #f0f0f0; padding: 10px;">
        <!-- Content moved from Create Chatroom Section -->
        <!-- This content is now below "Topic 3" -->
      </section>
    </main>
  </div>
</template>

<style scoped>
/* Add your CSS here */
</style>
